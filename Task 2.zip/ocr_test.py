# https://pandey.github.io/posts/transliterate-devanagari-to-latin.html 
import PyPDF2 as pypdf2
from wand.image import Image
from PIL import Image as PIL_image
import io
import copy
import pytesseract
import pandas as pd
import os
import re

DATA_DIR = '.'

def pdf_page_to_png(src_pdf, pagenum = 0, resolution = 72,):
    """
    Returns specified PDF page as wand.image.Image png.
    :param PyPDF2.PdfFileReader src_pdf: PDF from which to take pages.
    :param int pagenum: Page number to take.
    :param int resolution: Resolution for resulting png in DPI.
    """
    dst_pdf = pypdf2.PdfFileWriter()
    dst_pdf.addPage(src_pdf.getPage(pagenum))

    pdf_bytes = io.BytesIO()
    dst_pdf.write(pdf_bytes)
    pdf_bytes.seek(0)

    img = Image(file = pdf_bytes, resolution = resolution)
    img.convert("png")

    return img

data = '%s/sample_poll.pdf' % DATA_DIR
pdf = pypdf2.PdfFileReader(open(data, 'rb'))
# fp = file(data
num_of_pages = pdf.getNumPages()
extract = ""

width = 851 - 100
height = 499 - 206
starth = 100
startv = 206

roll_width = 745 - 535
roll_height = 50 - 5
roll_starth = 535
roll_startv = 5

name_width = 528 - 70
name_height = 84 - 45
name_starth = 70
name_startv = 45

age_width = 135 - 85
age_height = 220 - 175
age_starth = 85
age_startv = 175

gender_width = 540 - 205
gender_height = 220 - 175
gender_starth = 205
gender_startv = 175

columns = 3
rows = 10
data_list = list()
for i in range(num_of_pages):
    if i < 2:
        continue
    # if i >= num_of_pages - 1:
    if i > 2:
        break
    print("Page: %d" % i)
    img = pdf_page_to_png(pdf, i, resolution=300)
    img.save(filename='%s/sample_roll_%d.png' % (DATA_DIR, i))
    counter = 0
    for rr in range (rows):
        for cc in range (columns):
            # print(width*cc + starth, height*rr + startv, width=width, height=height)# + starth, height*(rr + 1) + startv)
            # print(width*cc + starth, height*rr + startv, width, height)
            # crop = img.crop(width*cc + starth, height*rr + startv, width=width, height=height)
            # print(width*cc + starth, height*rr + startv, width*(cc+1) + starth, height*(rr+1) + startv)
            # if counter==0:
                # counter += 1
                # continue
            # image_copy = copy.deepcopy(img)
            # crop = image_copy.crop(width*cc + starth, height*rr + startv, width*(cc+1) + starth, height*(rr+1) + startv)
            # print(roll_starth, roll_starth + roll_width, roll_startv, roll_startv + roll_height)
            with img[width*cc + starth:width*(cc+1) + starth, height*rr + startv:height*(rr+1) + startv] as crop:
                crop.save(filename='%s/temp_%d_%d.png' % (DATA_DIR, rr, cc))
                # print(roll_starth, roll_starth + roll_width, roll_startv, roll_startv + roll_height)
                # load_crop = Image(filename='%s/temp_%d_%d.png' % (DATA_DIR, rr, cc))
                with crop[roll_starth: roll_starth + roll_width, roll_startv : roll_startv + roll_height] as roll_number:
                    roll_number.save(filename='%s/roll_number_%d_%d.png' % (DATA_DIR, rr, cc))
                    load_roll_number = PIL_image.open('%s/roll_number_%d_%d.png' % (DATA_DIR, rr, cc))
                    roll = pytesseract.image_to_string(load_roll_number, config ='--oem 3 --psm 6')
                    roll = re.sub('\s+', '_', roll)
                    os.remove('%s/roll_number_%d_%d.png' % (DATA_DIR, rr, cc))
                    # print(text)
                with crop[name_starth: name_starth + name_width, name_startv : name_startv + name_height] as name:
                    name.save(filename='%s/name_%d_%d.png' % (DATA_DIR, rr, cc))
                    load_name = PIL_image.open('%s/name_%d_%d.png' % (DATA_DIR, rr, cc))
                    name = pytesseract.image_to_string(load_name, lang='script/Devanagari', config ='--oem 3 --psm 6')
                    name = re.sub('\s+', '_', name)
                    os.remove('%s/name_%d_%d.png' % (DATA_DIR, rr, cc))
                    # print(text)
                with crop[age_starth: age_starth + age_width, age_startv : age_startv + age_height] as age:
                    age.save(filename='%s/age_%d_%d.png' % (DATA_DIR, rr, cc))
                    load_age = PIL_image.open('%s/age_%d_%d.png' % (DATA_DIR, rr, cc))
                    age = pytesseract.image_to_string(load_age, config ='--oem 3 --psm 6')
                    age = re.sub('\s+', '_', age)
                    os.remove('%s/age_%d_%d.png' % (DATA_DIR, rr, cc))
                    # print(text)
                with crop[gender_starth: gender_starth + gender_width, gender_startv : gender_startv + gender_height] as gender:
                    gender.save(filename='%s/gender_%d_%d.png' % (DATA_DIR, rr, cc))
                    load_gender = PIL_image.open('%s/gender_%d_%d.png' % (DATA_DIR, rr, cc))
                    gender = pytesseract.image_to_string(load_gender, lang='script/Devanagari', config ='--oem 3 --psm 6')
                    gender = re.sub('\s+', '_', gender)
                    os.remove('%s/gender_%d_%d.png' % (DATA_DIR, rr, cc))
                data_list.append([roll, name, age, gender])
                    # print(text)

            print("    Row %d, Column %d" % (rr, cc))
    os.remove('%s/sample_roll_%d.png' % (DATA_DIR, i))
    print("Page Number Complete: %d" % i)

data_df = pd.DataFrame(data_list, columns=['roll_number', 'name', 'age', 'gender'])
data_df.to_csv('%s/sample_data.csv' % DATA_DIR, index=False)
    # input()

#844x498
#100x206


